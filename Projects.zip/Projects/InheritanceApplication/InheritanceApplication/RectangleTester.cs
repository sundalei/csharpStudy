﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InheritanceApplication
{
    class Shape
    {
        protected int width;
        protected int height;

        public void setWidth(int width)
        {
            this.width = width;
        }

        public void setHeight(int height)
        {
            this.height = height;
        }
    }

    class Rectangle : Shape
    {
        public int getArea()
        {
            return (width * height);
        }
    }

    class RectangleTester
    {
        static void Main(string[] args)
        {
            Rectangle rect = new Rectangle();

            rect.setWidth(5);
            rect.setHeight(7);

            Console.WriteLine("total area: {0}", rect.getArea());
            Console.ReadKey();
        }
    }
}
