﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StringApplication
{
    class StringCompare
    {
        static void Main(string[] args)
        {
            string str1 = "This is test";
            string str2 = "This is text";

            if (string.Compare(str1, str2) == 0)
            {
                Console.WriteLine(str1 + " and " + str2 + " are equal.");
            }
            else
            {
                Console.WriteLine(str1 + " and " + str2 + " are not equal.");
            }

            Console.ReadKey();
        }
    }
}
