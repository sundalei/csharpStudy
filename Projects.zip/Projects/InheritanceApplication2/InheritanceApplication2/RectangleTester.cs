﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InheritanceApplication2
{
    class Shape
    {
        public void setWidth(int width) 
        {
            this.width = width;
        }

        public void setHeight(int height)
        {
            this.height = height;
        }

        protected int width;
        protected int height;
    }

    public interface PaintCost
    {
        int getCost(int area);
    }

    class Rectangle : Shape, PaintCost
    {
        public int getArea()
        {
            return (width * height);
        }

        public int getCost(int area)
        {
            return area * 70;
        }
    }

    class RectangleTester
    {
        static void Main(string[] args)
        {
            Rectangle rect = new Rectangle();
            int area;
            rect.setWidth(5);
            rect.setHeight(7);
            area = rect.getArea();

            Console.WriteLine("Total Area： {0}", rect.getArea());
            Console.WriteLine("Total Cost： ${0}", rect.getCost(area));
            Console.ReadKey();
        }
    }
}
