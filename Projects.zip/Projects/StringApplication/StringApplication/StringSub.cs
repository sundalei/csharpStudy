﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StringApplication
{
    class StringSub
    {
        static void Main(string[] args)
        {
            string str = "Last night I dreamt of San Pedro";
            Console.WriteLine(str);
            string subString = str.Substring(23);
            Console.WriteLine(subString);
            Console.ReadKey();
        }
    }
}
