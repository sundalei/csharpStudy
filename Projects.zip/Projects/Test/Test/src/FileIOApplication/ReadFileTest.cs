﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace FileIOApplication
{
    class ReadFileTest
    {
        static void Main(string[] args)
        {
            FileStream fs = new FileStream(@"D:\README", FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            FileStream fs2 = new FileStream(@"D:\OUT", FileMode.OpenOrCreate, FileAccess.Write, FileShare.ReadWrite);

            StringBuilder builder = new StringBuilder();
            byte[] buffer = new byte[2048];
            int length = 0;

            while (0 != (length = fs.Read(buffer, 0, 2048)))
            {
                var str = System.Text.Encoding.Default.GetString(buffer, 0, length);
                builder.Append(str);
                fs2.Write(buffer, 0, length);
            }

            fs.Close();
            fs2.Close();

            Console.WriteLine(builder.ToString());
            Console.ReadKey();
        }
    }
}
