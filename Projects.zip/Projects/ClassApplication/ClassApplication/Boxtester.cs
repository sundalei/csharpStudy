﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassApplication
{
    class Box
    {
        private double length;
        private double breadth;
        private double height;

        public void setLength(double length)
        {
            this.length = length;
        }

        public void setBreadth(double breadth)
        {
            this.breadth = breadth;
        }

        public void setHeight(double height)
        {
            this.height = height;
        }

        public double getVolumn()
        {
            return length * breadth * height;
        }
    }

    class Boxtester
    {
        static void Main(string[] args)
        {
            Box box1 = new Box();
            Box box2 = new Box();
            double volume = 0.0;

            box1.setHeight(5.0);
            box1.setLength(6.0);
            box1.setBreadth(7.0);

            box2.setHeight(10.0);
            box2.setLength(12.0);
            box2.setBreadth(13.0);

            volume = box1.getVolumn();
            Console.WriteLine("Volumn of Box1: {0}", volume);

            volume = box2.getVolumn();
            Console.WriteLine("Volumn of Box2: {0}", volume);

            Console.ReadKey();
        }
    }
}
