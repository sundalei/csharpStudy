﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassApplication
{
    class StaticVar
    {
        public static int num;

        public void count()
        {
            num++;
        }

        public static int getNum()
        {
            return num;
        }
    }

    class StaticTester
    {
        static void Main(string[] args)
        {
            StaticVar s1 = new StaticVar();
            StaticVar s2 = new StaticVar();

            s1.count();
            s1.count();
            s1.count();
            s2.count();
            s2.count();
            s2.count();

            Console.WriteLine("num of s1： {0}", StaticVar.getNum());
            Console.WriteLine("num of s2： {0}", StaticVar.getNum());
            Console.ReadKey();
        }
    }
}
