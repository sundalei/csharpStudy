﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassApplication
{
    class LineExample
    {
        private double length;

        public LineExample()
        {
            Console.WriteLine("instance object was created.");
        }

        ~LineExample()
        {
            Console.WriteLine("instance object was removed.");
        }

        public LineExample(double length)
        {
            Console.WriteLine("instance object was created with parameterized constructor");
            this.length = length;
        }

        public void setLength(double length)
        {
            this.length = length;
        }

        public double getLength()
        {
            return length;
        }

        static void Main(string[] args)
        {
            LineExample line = new LineExample(10.0);
            Console.WriteLine("Length of line: {0}", line.getLength());
            line.setLength(6.0);
            Console.WriteLine("Length of line: {0}", line.getLength());
            Console.ReadKey();
        }
    }
}
