﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorldApplication
{
    class HelloWorld
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!!");
            Console.ReadKey();
        }
    }
}
