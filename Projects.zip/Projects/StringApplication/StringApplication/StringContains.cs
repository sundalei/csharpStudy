﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StringApplication
{
    class StringContains
    {
        static void Main(string[] args)
        {
            string str = "This is test";
            if (str.Contains("test"))
            {
                Console.WriteLine("The sequence 'test' was found.");
            }
            Console.ReadKey();
        }
    }
}
